
import Product from './product/Product';
import './App.css';

function App() {
  return (
    <div className="App">
  
    <Product />
    </div>
  );
}

export default App;
